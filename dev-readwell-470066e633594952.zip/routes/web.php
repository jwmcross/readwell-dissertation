<?php

use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\CarerController;
use App\Http\Controllers\Admin\ChildController;
use App\Http\Controllers\Admin\FamilyController;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\RegisterController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\SessionController;
use App\Http\Controllers\Admin\UserController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/login');

Auth::routes(['register' => false]);

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => ['auth']], function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');

    // Permissions
    Route::resource('permissions', PermissionController::class, ['except' => ['store', 'update', 'destroy']]);

    // Roles
    Route::resource('roles', RoleController::class, ['except' => ['store', 'update', 'destroy']]);

    // Users
    Route::resource('users', UserController::class, ['except' => ['store', 'update', 'destroy']]);

    // Audit Logs
    Route::resource('audit-logs', AuditLogController::class, ['except' => ['store', 'update', 'destroy', 'create', 'edit']]);

    // Child
    Route::resource('children', ChildController::class, ['except' => ['store', 'update', 'destroy']]);

    // Carer
    Route::resource('carers', CarerController::class, ['except' => ['store', 'update', 'destroy']]);

    // Session
    Route::resource('sessions', SessionController::class, ['except' => ['store', 'update', 'destroy']]);

    // Register
    Route::resource('registers', RegisterController::class, ['except' => ['store', 'update', 'destroy']]);

    // Booking
    Route::resource('bookings', BookingController::class, ['except' => ['store', 'update', 'destroy']]);

    // Family
    Route::resource('families', FamilyController::class, ['except' => ['store', 'update', 'destroy']]);
});
