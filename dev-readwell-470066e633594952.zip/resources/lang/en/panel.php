<?php

return [
    'site_title' => 'Readwell',
];
