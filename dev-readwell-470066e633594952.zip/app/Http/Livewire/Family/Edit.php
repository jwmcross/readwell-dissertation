<?php

namespace App\Http\Livewire\Family;

use App\Models\Family;
use Livewire\Component;

class Edit extends Component
{
    public Family $family;

    public function mount(Family $family)
    {
        $this->family = $family;
    }

    public function render()
    {
        return view('livewire.family.edit');
    }

    public function submit()
    {
        $this->validate();

        $this->family->save();

        return redirect()->route('admin.families.index');
    }

    protected function rules(): array
    {
        return [
            'family.family_name' => [
                'string',
                'nullable',
            ],
        ];
    }
}
