<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Register;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class RegisterController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('register_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.register.index');
    }

    public function create()
    {
        abort_if(Gate::denies('register_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.register.create');
    }

    public function edit(Register $register)
    {
        abort_if(Gate::denies('register_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.register.edit', compact('register'));
    }

    public function show(Register $register)
    {
        abort_if(Gate::denies('register_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $register->load('child');

        return view('admin.register.show', compact('register'));
    }
}
