<?php

namespace App\Models;

use \DateTimeInterface;
use App\Support\HasAdvancedFilter;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Booking extends Model
{
    use HasFactory;
    use HasAdvancedFilter;
    use SoftDeletes;
    use Auditable;

    public const MONDAY_SELECT = [
        'Morning'   => 'Morning',
        'Afternoon' => 'Afternoon',
        'Full Day'  => 'Full Day',
    ];

    public const FRIDAY_SELECT = [
        'Morning'   => 'Morning',
        'Afternoon' => 'Afternoon',
        'Full Day'  => 'Full Day',
    ];

    public const TUESDAY_SELECT = [
        'Morning'   => 'Morning',
        'Afternoon' => 'Afternoon',
        'Full Day'  => 'Full Day',
    ];

    public const THURSDAY_SELECT = [
        'Morning'   => 'Morning',
        'Afternoon' => 'Afternoon',
        'Full Day'  => 'Full Day',
    ];

    public const WEDNESDAY_SELECT = [
        'Morning'   => 'Morning',
        'Afternoon' => 'Afternoon',
        'Full Day'  => 'Full Day',
    ];

    public $table = 'bookings';

    public $orderable = [
        'id',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'child.firstname',
    ];

    public $filterable = [
        'id',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'child.firstname',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'child_id',
    ];

    public function getMondayLabelAttribute($value)
    {
        return static::MONDAY_SELECT[$this->monday] ?? null;
    }

    public function getTuesdayLabelAttribute($value)
    {
        return static::TUESDAY_SELECT[$this->tuesday] ?? null;
    }

    public function getWednesdayLabelAttribute($value)
    {
        return static::WEDNESDAY_SELECT[$this->wednesday] ?? null;
    }

    public function getThursdayLabelAttribute($value)
    {
        return static::THURSDAY_SELECT[$this->thursday] ?? null;
    }

    public function getFridayLabelAttribute($value)
    {
        return static::FRIDAY_SELECT[$this->friday] ?? null;
    }

    public function child()
    {
        return $this->belongsTo(Child::class);
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
