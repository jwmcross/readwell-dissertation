<?php

namespace App\Models;

use \DateTimeInterface;
use App\Support\HasAdvancedFilter;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Carer extends Model
{
    use HasFactory;
    use HasAdvancedFilter;
    use SoftDeletes;
    use Auditable;

    public const TITLE_SELECT = [
        'Mr'   => 'Mr',
        'Mrs'  => 'Mrs',
        'Miss' => 'Miss',
        'Rev'  => 'Rev',
        'Dr'   => 'Dr',
    ];

    public $table = 'carers';

    public $orderable = [
        'id',
        'title',
        'firstname',
        'lastname',
        'address',
        'post_code',
        'contact_number',
        'work_contact_number',
        'email',
        'national_insurance_number',
        'family.family_name',
    ];

    public $filterable = [
        'id',
        'title',
        'firstname',
        'lastname',
        'address',
        'post_code',
        'contact_number',
        'work_contact_number',
        'email',
        'national_insurance_number',
        'family.family_name',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'title',
        'firstname',
        'lastname',
        'address',
        'post_code',
        'contact_number',
        'work_contact_number',
        'email',
        'national_insurance_number',
        'family_id',
    ];

    public function getTitleLabelAttribute($value)
    {
        return static::TITLE_SELECT[$this->title] ?? null;
    }

    public function family()
    {
        return $this->belongsTo(Family::class);
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
