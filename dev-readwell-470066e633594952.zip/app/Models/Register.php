<?php

namespace App\Models;

use \DateTimeInterface;
use App\Support\HasAdvancedFilter;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Register extends Model
{
    use HasFactory;
    use HasAdvancedFilter;
    use SoftDeletes;

    public const AGE_GROUP_SELECT = [
        '1' => 'Under 2s',
        '2' => '3 - 4 year olds',
    ];

    public $table = 'registers';

    public $orderable = [
        'id',
        'title',
        'register_date',
        'start_time',
        'end_time',
        'age_group',
    ];

    public $filterable = [
        'id',
        'title',
        'register_date',
        'start_time',
        'end_time',
        'age_group',
        'child.firstname',
    ];

    protected $dates = [
        'register_date',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'title',
        'register_date',
        'start_time',
        'end_time',
        'age_group',
    ];

    public function getRegisterDateAttribute($value)
    {
        return $value ? Carbon::parse($value)->format(config('project.date_format')) : null;
    }

    public function setRegisterDateAttribute($value)
    {
        $this->attributes['register_date'] = $value ? Carbon::createFromFormat(config('project.date_format'), $value)->format('Y-m-d') : null;
    }

    public function getAgeGroupLabelAttribute($value)
    {
        return static::AGE_GROUP_SELECT[$this->age_group] ?? null;
    }

    public function child()
    {
        return $this->belongsToMany(Child::class);
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
